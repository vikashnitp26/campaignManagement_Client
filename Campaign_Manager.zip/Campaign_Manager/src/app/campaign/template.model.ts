export class EmailTemplate {
    email: string;
    subject: string;
    html: Object
}
