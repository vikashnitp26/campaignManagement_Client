export class User {
    name: string;
    country: string;
    state: string;
    email: string;
}
